
using System;
using System.Diagnostics;

namespace ProjektWzorcowy
{
class Program
  {
   static ulong fib(ulong n)
    {
     switch (n)
       {
        case 0: return 1;
        case 1: return 1;
        default: return fib(n - 1) + fib(n - 2);
       }
    } /* fib() */

   static void Main(string[] args)
     {
      const int NIter = 10; // liczba powt�rze� testu
      Console.WriteLine("n\tt[s]");
      for (ulong u = 30; u < 48; u++)
        {
         double ElapsedSeconds;
         long ElapsedTime = 0, MinTime = long.MaxValue, MaxTime = long.MinValue, IterationElapsedTime;
         for(int n = 0; n < (NIter + 1 + 1); ++n) // odejmujemy warto�ci skrajne
           {
            long StartingTime = Stopwatch.GetTimestamp();
            ulong r = fib(u);
            long EndingTime = Stopwatch.GetTimestamp();
            IterationElapsedTime = EndingTime - StartingTime;
            ElapsedTime += IterationElapsedTime;
              //Console.Write("Iter[" + n + "]:" + IterationElapsedTime + "\t");
            if (IterationElapsedTime < MinTime) MinTime = IterationElapsedTime;
            if (IterationElapsedTime > MaxTime) MaxTime = IterationElapsedTime;
           }
		   
         ElapsedTime -= (MinTime + MaxTime);
         ElapsedSeconds = ElapsedTime * (1.0 / (NIter * Stopwatch.Frequency));
         Console.WriteLine("{0}\t{1}", u, ElapsedSeconds.ToString("F4"));
       }
     }
  }
}
